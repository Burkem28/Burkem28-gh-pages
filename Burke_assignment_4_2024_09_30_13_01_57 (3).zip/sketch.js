var blueBackground = true;

function setup() {
  createCanvas(400, 400);
  background(50, 50, 255);
}

function draw() {

}


function mouseClicked(){
  
  //Clicking in the upper left corner set the line and point color to white
  if(mouseX < 10 && mouseY < 10){
    stroke('white');

  //Clicking in the lower right corner set the line and point color to black
  } else if(mouseX > 390 && mouseY > 390){
    stroke('black');

  //Clicking anywhere else draws a dot and lines to a series of dots at the top and the bottom
  } else {
    
    print("dot", mouseX, mouseY);
    strokeWeight(15);
  
    point(mouseX, mouseY);
  
    for (let i=1; i<10; i++){
    
      strokeWeight(5);
  
      point(width/10 * i, 10);
      point(width/10 * i, 390);
    
      strokeWeight(1);
      line(mouseX, mouseY, width/10 * i, 10);
      line(mouseX, mouseY, width/10 * i, 390);
    
    }
  }
  
}

function keyPressed(){
  
  //If the background is blue change it to red
  if(blueBackground === true){
    
    background(255, 50, 50);
    
    blueBackground = false;
    
  //If the background is red, change it to blue
  } else {
    
    background(50, 50, 255);
    
    blueBackground = true;
    
  }  
}