var x = 0;

function setup() {
  
  createCanvas(800, 650);
  
  //sky
  background('blue');
  angleMode(DEGREES);

}

function draw() {
  noStroke();
  fill('green')
  
  //grass
  rect(0, 550, 900, 900);
  
  
  //clouds

  cloud(0, 0);
  

  //rain
  
  raindrop(x, 20);
}


//draws the cloud
function cloud(x, y){

  for(x = 0; x < width + 70; x += 70){
    push();//start the drawing
  
    translate(x, y);
    noStroke();
    scale(2, 2);
  
    fill(220)
    ellipse(0, 9, 50, 50);
    pop();//end the drawing 
  }

  
}


//draws the rain
function raindrop(x,y){
   
  for(x = 0; x < 850; x += 80){
    for(y = 100; y < 550; y += 85){
      print("X =",x);
      push();//starts the drawing
      translate(x, y); 
      angleMode(DEGREES);
      rotate(-25);
      scale(.3);
      fill('rgb(0,223,255)');
      ellipse (50,50, 40,40);
      triangle (33,40, 67,40, 50,5);
      ellipse (100,100, 40,40);
      triangle (83,90, 117,90, 100,55);
      ellipse (150,150, 40,40);
      triangle (133,140, 167,140, 150,105);
      ellipse (200,200, 40,40);
      triangle (183,190, 217,190, 200,155);

      
      pop();//ends the drawing
  
    
    }
  }
}