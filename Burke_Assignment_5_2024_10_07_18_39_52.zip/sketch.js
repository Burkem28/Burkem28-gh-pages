var leftButtonColor = '#0008BD';

var powerButtonColor = '#1C218A';

var centerButtonColor = '#1F2033';

var mouseLocation = 0;

var powerButtonX = 750;

var centerButtonX = 390;

var leftButtonX = 160;

var buttonY = 520;


function setup() {
    createCanvas(900, 600);
    ellipseMode (RADIUS);
    
    stroke('royalblue');
    strokeWeight(15);
  
}

function draw() {
    fill('#31323D');
    background('#232557');
    
    
    //create outside frame
    stroke('royalblue');
    strokeWeight(15);
  
    rect(0, 0, 900, 600, 20);
      
  
    //power button
    fill(powerButtonColor);
    stroke('black');
    strokeWeight(2);
    ellipse(powerButtonX, buttonY, 45, 45);
  
  
    //center button
    fill(centerButtonColor);
    stroke('black');
    strokeWeight(2);
    rect(centerButtonX, buttonY-45, 120, 90, 15);
  
  
    //left button
    fill(leftButtonColor);
    stroke('black');
    strokeWeight(2);
    ellipse(leftButtonX, buttonY, 45, 45);
  
}

function mousePressed(){
    
    var powerDist = dist(mouseX, mouseY, powerButtonX, buttonY);
	if (powerDist <= 45){
        
        
        if (powerButtonColor == '#1C218A'){
          
          //Turns Power button color to #232557 
          powerButtonColor = '#232557';
          
        }
        
        else{
          
          //Turns Power button color back to #1C218A
          powerButtonColor = '#1C218A';
          
        }
      
    }
    
    else if (((mouseX >= centerButtonX) && (mouseX <= centerButtonX + 120)) && ((mouseY >= buttonY-45) && (mouseY <= buttonY+45))){
      
      if (centerButtonColor == '#1F2033'){
        
        
        // turns center button color to #31323D   
        centerButtonColor = '#31323D';
        
      }
      
      else{
        
          // turns center button color back to #1F2033   
          centerButtonColor = '#1F2033';
        
      }
      
    } 

}

function keyPressed(){
  

  var leftButtonDist = dist(mouseX, mouseY, leftButtonX, buttonY);
  if (key === 'f'){

    
    if (leftButtonDist <= 45){

      
      if (leftButtonColor === '#0008BD'){
        
        //Turns left button color to #1F2033
        leftButtonColor = '#1F2033';
        
      }
      
      else{
        
        //Turns left button color back to #0008BD
        leftButtonColor = '#0008BD';
        
      }  
          
    }
    
  } 
  
}